var slidesGallery = document.getElementsByClassName("mySliderGalleryImg");
var sliderGalleryBack = document.querySelector('#sliderGalleryBack');
var sliderGalleryNext = document.querySelector('#sliderGalleryNext');
var slideGalleryIndex = 1;

sliderGalleryBack.addEventListener("click", function() 
{
  showGallerySlides(slideGalleryIndex -= 1); 
});

sliderGalleryNext.addEventListener("click", function() 
{
  showGallerySlides(slideGalleryIndex += 1); 
});

showGallerySlides(slideGalleryIndex);

function showGallerySlides(n) 
{
  if (n > slidesGallery.length) 
  {
	slideGalleryIndex = 1;
  }  
  
  if (n < 1) 
  {
	slideGalleryIndex = slidesGallery.length;
  }
  
  for (var i = 0; i < slidesGallery.length; i++) 
  {
    slidesGallery[i].classList.remove('mySliderGalleryImg-active'); 
  }

  slidesGallery[slideGalleryIndex-1].classList.add('mySliderGalleryImg-active'); 
  console.log("click2");
}