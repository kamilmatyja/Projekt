var slidesShop = document.getElementsByClassName("myShopImg");
var color = document.getElementsByClassName("shop-color");

var slideShopIndex = 1;

window.addEventListener("load", function() 
{
  showSlides(slideShopIndex);
});

function currentSlide(n)
{
  showSlides(slideShopIndex = n);
}

function showSlides(n)
{
  if (n > slidesShop.length) 
  {
	  slideShopIndex = 1;
  }
  
  if (n < 1) 
  {
	slideShopIndex = slidesShop.length
  }
  
  for (var i = 0; i < slidesShop.length; i++) 
  {
    slidesShop[i].classList.remove('myShopImg-active');
  }
  
  for (var i = 0; i < color.length; i++) 
  {
    color[i].classList.remove('shop-color-active');
  }
  
  slidesShop[slideShopIndex-1].classList.add('myShopImg-active');
  color[slideShopIndex-1].classList.add('shop-color-active');
}