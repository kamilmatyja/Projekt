var shopHeartIcon = document.querySelector('.fa-heart');

shopHeartIcon.addEventListener('click', function() 
{
  shopHeartIcon.classList.toggle('far');
  shopHeartIcon.classList.toggle('fas');  
});