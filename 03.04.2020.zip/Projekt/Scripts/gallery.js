var galleryImg = document.getElementById("galleryImg");
var galleryCloseButton = document.getElementById("galleryCloseButton");

galleryCloseButton.addEventListener("click", function() 
{
  this.parentElement.classList.add('container-gallery');
  this.parentElement.classList.remove('container-gallery-active'); 
});

function gallery(n) 
{
  galleryImg.src = n.src;
  galleryImg.parentElement.classList.add('container-gallery-active'); 
  galleryImg.parentElement.classList.remove('container-gallery'); 
}